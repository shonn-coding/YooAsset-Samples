using System.Collections;
using System.Collections.Generic;
using UnityEditor.UIElements;

namespace YooAsset.Editor
{
	public class AssetBundleBrowserWindow
	{

	}
}