﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace YooAsset.Editor
{
	public class AssetBundleProfilerWindow
	{

	}
}