﻿
namespace YooAsset.Editor
{
	public interface IContextObject
	{
	}
}