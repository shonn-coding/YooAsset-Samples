﻿
namespace YooAsset.Editor
{
    public interface IBuildTask
    {
        void Run(BuildContext context);
    }
}