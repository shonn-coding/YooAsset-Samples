﻿
namespace YooAsset
{
	public interface IAssetParam
	{
	}
}